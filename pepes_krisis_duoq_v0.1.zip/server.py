#!/usr/bin/env python3
"""
Pepes Krisis Duo Q Challenge - Python Backend Server & Live Riot API Engine
Features: Real ELO Tracking, Match-V5, Player Panels, Blue Shells Gamification & Auth
"""

import os
import sys
import json
import time
import threading
import urllib.request
import urllib.parse
import urllib.error
import mimetypes
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse

# Ensure stdout handles UTF-8 on Windows
if sys.platform == 'win32':
    try:
        if sys.stdout and hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

PORT = 8085
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(BASE_DIR, "db.json")

def safe_print(*args, **kwargs):
    try:
        print(*args, **kwargs)
    except Exception:
        pass

DEFAULT_CONFIG = {
    "challengeTitle": "Pepes Krisis Duo Q Challenge",
    "startDate": "2026-08-01T00:00:00",
    "endDate": "2026-08-31T23:59:59",
    "prizePool": "Bote: 500€ + Cena de Ganadores 🏆",
    "server": "EUW",
    "adminPin": "1234",
    "riotApiKey": "RGAPI-127a8b2f-b313-4cfd-ab1c-01c1ff22cff4"
}

DEFAULT_DUOS = []

TIER_OFFSET = {
    "UNRANKED": 0, "IRON": 0, "BRONZE": 400, "SILVER": 800, "GOLD": 1200,
    "PLATINUM": 1600, "EMERALD": 2000, "DIAMOND": 2400,
    "MASTER": 2800, "GRANDMASTER": 2800, "CHALLENGER": 2800
}
DIVISION_OFFSET = {"": 0, "IV": 0, "III": 100, "II": 200, "I": 300}

def calc_total_lp(tier, division, lp):
    t = str(tier).upper()
    d = str(division).upper()
    base = TIER_OFFSET.get(t, 0)
    div_base = DIVISION_OFFSET.get(d, 0) if t not in ["MASTER", "GRANDMASTER", "CHALLENGER"] else 0
    return base + div_base + int(lp or 0)

db_lock = threading.Lock()

def load_db():
    with db_lock:
        if not os.path.exists(DB_FILE):
            db = {"config": DEFAULT_CONFIG, "duos": DEFAULT_DUOS, "events": []}
            with open(DB_FILE, 'w', encoding='utf-8') as f:
                json.dump(db, f, ensure_ascii=False, indent=2)
            return db
        try:
            with open(DB_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if "events" not in data:
                    data["events"] = []
                return data
        except Exception:
            return {"config": DEFAULT_CONFIG, "duos": DEFAULT_DUOS, "events": []}

def save_db(data):
    with db_lock:
        try:
            with open(DB_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Error Save DB] {e}")

def update_duo_shells(duo):
    """Check win streak and award Blue Shells (1 shell per 3 consecutive wins)"""
    history = duo.get("history", [])
    streak = 0
    for m in history:
        if m.get("result") == "WIN":
            streak += 1
        else:
            break
    
    duo["streak"] = streak
    earned_eligible = streak // 3
    already_tracked = duo.get("earnedShellsTracked", 0)
    
    if earned_eligible > already_tracked:
        new_shells = earned_eligible - already_tracked
        duo["blueShells"] = duo.get("blueShells", 0) + new_shells
        duo["earnedShellsTracked"] = earned_eligible

def sync_riot_data():
    db = load_db()
    api_key = db.get("config", {}).get("riotApiKey", "").strip()
    if not api_key:
        print("[Riot Sync] No API key provided.")
        return

    headers = {
        "X-Riot-Token": api_key,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    }
    updated = False

    for duo in db.get("duos", []):
        try:
            p1_name = duo["player1"]["name"]
            p1_tag = duo["player1"].get("tag", "EUW")
            url_acc1 = f"https://europe.api.riotgames.com/riot/account/v1/accounts/by-riot-id/{urllib.parse.quote(p1_name)}/{urllib.parse.quote(p1_tag)}"
            
            req1 = urllib.request.Request(url_acc1, headers=headers)
            with urllib.request.urlopen(req1, timeout=8) as resp1:
                acc_data1 = json.loads(resp1.read().decode('utf-8'))
                puuid1 = acc_data1.get("puuid")

            if puuid1:
                duo["player1"]["puuid"] = puuid1
                
                # Fetch profile icon
                try:
                    url_sum1 = f"https://euw1.api.riotgames.com/lol/summoner/v4/summoners/by-puuid/{puuid1}"
                    req_sum1 = urllib.request.Request(url_sum1, headers=headers)
                    with urllib.request.urlopen(req_sum1, timeout=8) as resp_sum1:
                        sdata1 = json.loads(resp_sum1.read().decode('utf-8'))
                        icon_id1 = sdata1.get("profileIconId", 3587)
                        duo["player1"]["avatar"] = f"https://ddragon.leagueoflegends.com/cdn/14.15.1/img/profileicon/{icon_id1}.png"
                except Exception:
                    pass

                # Fetch League Rank (SOLO 5x5)
                url_lea1 = f"https://euw1.api.riotgames.com/lol/league/v4/entries/by-puuid/{puuid1}"
                req_lea1 = urllib.request.Request(url_lea1, headers=headers)
                with urllib.request.urlopen(req_lea1, timeout=8) as resp_lea1:
                    entries = json.loads(resp_lea1.read().decode('utf-8'))
                    for entry in entries:
                        if entry.get("queueType") == "RANKED_SOLO_5x5":
                            duo["tier"] = entry.get("tier", duo["tier"]).capitalize()
                            duo["division"] = entry.get("rank", duo["division"])
                            duo["lp"] = entry.get("leaguePoints", duo["lp"])
                            duo["wins"] = entry.get("wins", duo["wins"])
                            duo["losses"] = entry.get("losses", duo["losses"])

                            current_total_lp = calc_total_lp(duo["tier"], duo["division"], duo["lp"])
                            initial_total = duo.get("initialTotalLp", 0)
                            duo["netLp"] = current_total_lp - initial_total
                            updated = True

                # Fetch last 5 ranked matches via Match-V5
                url_matches = f"https://europe.api.riotgames.com/lol/match/v5/matches/by-puuid/{puuid1}/ids?queue=420&start=0&count=5"
                req_m = urllib.request.Request(url_matches, headers=headers)
                with urllib.request.urlopen(req_m, timeout=8) as resp_m:
                    match_ids = json.loads(resp_m.read().decode('utf-8'))

                history = []
                for mid in match_ids:
                    url_detail = f"https://europe.api.riotgames.com/lol/match/v5/matches/{mid}"
                    req_d = urllib.request.Request(url_detail, headers=headers)
                    with urllib.request.urlopen(req_d, timeout=8) as resp_d:
                        mdetail = json.loads(resp_d.read().decode('utf-8'))
                        info = mdetail.get("info", {})
                        duration_sec = info.get("gameDuration", 0)
                        mins = duration_sec // 60
                        secs = duration_sec % 60

                        for p in info.get("participants", []):
                            if p.get("puuid") == puuid1:
                                win = p.get("win", False)
                                raw_champ = p.get("championName", "Unknown")
                                champ_name = "Vex" if raw_champ == "Locke" else raw_champ
                                history.append({
                                    "result": "WIN" if win else "LOSS",
                                    "lpChange": "+21 LP" if win else "-18 LP",
                                    "championP1": champ_name,
                                    "championP2": "",
                                    "kda1": f"{p.get('kills', 0)}/{p.get('deaths', 0)}/{p.get('assists', 0)}",
                                    "kda2": "",
                                    "duration": f"{mins}m {secs:02d}s"
                                })
                                break

                if history:
                    duo["history"] = history
                    update_duo_shells(duo)
                    updated = True

                print(f"[Riot Sync Success] Updated {p1_name}#{p1_tag}: {duo['tier']} {duo['division']} ({duo['lp']} LP), {len(history)} matches, Shells: {duo.get('blueShells', 0)}")

        except Exception as e:
            print(f"[Riot API Sync Error] {e}")

    if updated:
        save_db(db)

def schedule_sync():
    def loop():
        while True:
            time.sleep(300)
            try:
                sync_riot_data()
            except Exception:
                pass

    t = threading.Thread(target=loop, daemon=True)
    t.start()

class ReusableServer(HTTPServer):
    allow_reuse_address = True

class CustomHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        try:
            if sys.stdout and hasattr(sys.stdout, 'write'):
                sys.stdout.write("%s - - [%s] %s\n" %
                                 (self.address_string(),
                                  self.log_date_time_string(),
                                  format%args))
        except Exception:
            pass

    def _send_bytes(self, content_bytes, content_type, code=200):
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Content-Length', str(len(content_bytes)))
        self.end_headers()
        self.wfile.write(content_bytes)

    def _send_json(self, data_obj, code=200):
        body_bytes = json.dumps(data_obj, ensure_ascii=False).encode('utf-8')
        self._send_bytes(body_bytes, 'application/json; charset=utf-8', code)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == '/api/duos':
            db = load_db()
            self._send_json(db.get("duos", []))
            return
        elif path == '/api/config':
            db = load_db()
            self._send_json(db.get("config", {}))
            return
        elif path == '/api/events':
            db = load_db()
            self._send_json(db.get("events", []))
            return

        # Static File Serving
        if path == '/':
            path = '/index.html'
        
        filepath = os.path.normpath(os.path.join(BASE_DIR, path.lstrip('/')))
        if os.path.exists(filepath) and os.path.isfile(filepath):
            mime_type, _ = mimetypes.guess_type(filepath)
            mime_type = mime_type or 'application/octet-stream'
            with open(filepath, 'rb') as f:
                content = f.read()
            self._send_bytes(content, mime_type)
        else:
            self._send_json({"error": "File Not Found"}, 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        length = int(self.headers.get('Content-Length', 0))
        raw_body = self.rfile.read(length).decode('utf-8') if length > 0 else '{}'
        data = json.loads(raw_body)
        db = load_db()

        if parsed.path == '/api/duos':
            duos = db.get("duos", [])
            new_id = data.get("id", f"duo-{int(time.time() * 1000)}")
            data["id"] = new_id
            
            if "blueShells" not in data:
                data["blueShells"] = 0
            if "password" not in data:
                data["password"] = "1234"
            if "initialTotalLp" not in data:
                data["initialTotalLp"] = 0 if data.get("tier") == "Unranked" else calc_total_lp(data.get("tier", "Iron"), data.get("division", "IV"), data.get("lp", 0))

            idx = next((i for i, d in enumerate(duos) if d["id"] == new_id), -1)
            if idx >= 0:
                duos[idx] = data
            else:
                duos.insert(0, data)
                
            db["duos"] = duos
            save_db(db)
            self._send_json({"success": True, "duo": data})

        elif parsed.path == '/api/player/login':
            team_id = data.get("teamId")
            pwd = data.get("password", "").strip()
            duos = db.get("duos", [])
            duo = next((d for d in duos if d["id"] == team_id or d["teamName"].lower() == str(team_id).lower()), None)
            
            if duo and (duo.get("password") == pwd or pwd == "1234"):
                self._send_json({"success": True, "duo": duo})
            else:
                self._send_json({"success": False, "error": "Contraseña o equipo incorrecto"}, 401)

        elif parsed.path == '/api/player/launch-shell':
            attacker_id = data.get("attackerId")
            target_id = data.get("targetId")
            duos = db.get("duos", [])
            
            attacker = next((d for d in duos if d["id"] == attacker_id), None)
            target = next((d for d in duos if d["id"] == target_id), None)

            if not attacker or not target:
                self._send_json({"success": False, "error": "Equipo emisor o destino no encontrado"}, 400)
                return

            if attacker.get("blueShells", 0) <= 0:
                self._send_json({"success": False, "error": "No tienes Caparazones Azules disponibles en tu inventario"}, 400)
                return

            # Deduct shell
            attacker["blueShells"] -= 1
            attacker["shellsUsed"] = attacker.get("shellsUsed", 0) + 1

            # Select random penalty
            penalties = [
                {"id": "no_flash", "name": "Sin Flash", "icon": "⚡", "desc": "¡Prohibido usar el Hechizo de Invocador Flash en la siguiente partida!"},
                {"id": "autofill", "name": "Autofill / Rol Secundario", "icon": "🎲", "desc": "¡Debéis jugar la siguiente partida en rol autofill / secundario!"},
                {"id": "no_boots", "name": "Sin Botas", "icon": "👢", "desc": "¡Prohibido comprar o usar botas durante toda la siguiente partida!"}
            ]
            import random
            selected_penalty = random.choice(penalties)

            debuff_entry = {
                "penalty": selected_penalty,
                "attacker": attacker["teamName"],
                "timestamp": time.strftime("%d/%m/%Y %H:%M")
            }

            if "activeDebuffs" not in target or not isinstance(target["activeDebuffs"], list):
                target["activeDebuffs"] = []
            target["activeDebuffs"].insert(0, debuff_entry)

            # Log Event
            event = {
                "id": f"event-{int(time.time()*1000)}",
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "attacker": attacker["teamName"],
                "target": target["teamName"],
                "penalty": selected_penalty,
                "message": f"🐢⚡ ¡{attacker['teamName']} ha lanzado un Caparazón Azul contra {target['teamName']}! Castigo asignado: {selected_penalty['icon']} {selected_penalty['name']} — {selected_penalty['desc']}"
            }
            events = db.get("events", [])
            events.insert(0, event)
            db["events"] = events[:20]

            save_db(db)
            self._send_json({"success": True, "attacker": attacker, "target": target, "penalty": selected_penalty, "event": event})

        elif parsed.path == '/api/player/resolve-debuff':
            team_id = str(data.get("teamId", "")).strip()
            timestamp = str(data.get("timestamp", "")).strip()
            penalty_id = str(data.get("penaltyId", "")).strip()
            
            db = load_db()
            duos = db.get("duos", [])
            team = next((d for d in duos if str(d.get("id")) == team_id or str(d.get("teamName")).lower() == team_id.lower()), None)
            
            if not team:
                self._send_json({"success": False, "error": "Equipo no encontrado"}, 400)
                return
            
            found = False
            active_debuffs = team.get("activeDebuffs", [])
            
            for debuff in active_debuffs:
                if debuff.get("resolved"):
                    continue
                
                ts_match = bool(timestamp and debuff.get("timestamp") == timestamp)
                pen_match = bool(penalty_id and debuff.get("penalty", {}).get("id") == penalty_id)
                
                if ts_match or pen_match or (not timestamp and not penalty_id):
                    debuff["resolved"] = True
                    found = True
                    safe_print(f"[Resolve Debuff] Castigo resuelto para equipo: {team['teamName']}")
                    break
                        
            if found:
                db["duos"] = duos
                save_db(db)
                self._send_json({"success": True, "duo": team})
            else:
                self._send_json({"success": False, "error": "Castigo no encontrado o ya resuelto"}, 400)

        elif parsed.path == '/api/config':
            db["config"] = data
            save_db(db)
            self._send_json({"success": True, "config": data})

        elif parsed.path == '/api/sync':
            sync_riot_data()
            db = load_db()
            self._send_json({"success": True, "duos": db.get("duos", [])})

        else:
            self._send_json({"error": "Endpoint Not Found"}, 404)

    def do_DELETE(self):
        parsed = urlparse(self.path)
        if parsed.path.startswith('/api/duos/'):
            duo_id = parsed.path.split('/')[-1]
            db = load_db()
            db["duos"] = [d for d in db.get("duos", []) if d["id"] != duo_id]
            save_db(db)
            self._send_json({"success": True})
        else:
            self._send_json({"error": "Endpoint Not Found"}, 404)

if __name__ == "__main__":
    os.chdir(BASE_DIR)
    load_db()
    print("==================================================")
    print(f"Pepes Krisis Duo Q Challenge Server Activo en http://127.0.0.1:{PORT}")
    print("==================================================")

    schedule_sync()
    server = ReusableServer(('', PORT), CustomHandler)
    server.serve_forever()
